#ifndef __CLASSLESS_C___
#define __CLASSLESS_C__
    int decoupageNumber();
    int underNetwork(int decoupe);
    char* binaryNBits(char* byteToBinary,int decoupe);
    void adresseReseauxEtBroadcast(char* cidrIp,int number);
    char* getNetworkPart(char* cidrIp);
    
#endif